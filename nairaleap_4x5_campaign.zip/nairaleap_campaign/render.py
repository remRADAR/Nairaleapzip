from pathlib import Path
from playwright.sync_api import sync_playwright

out = Path('/home/ubuntu/nairaleap_campaign/renders')
out.mkdir(exist_ok=True)
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':1080,'height':1350}, device_scale_factor=1)
    page.goto('file:///home/ubuntu/nairaleap_campaign/campaign.html')
    page.wait_for_timeout(1500)
    for el in page.locator('.stage').all():
        service_id = el.get_attribute('data-id')
        el.screenshot(path=str(out / f'{service_id}.png'))
    browser.close()
