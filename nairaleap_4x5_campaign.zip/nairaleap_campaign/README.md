# NairaLeap 4:5 Service Campaign

Editable source and static 4:5 renders for the 12 NairaLeap portal services.

## Direction

- 1080 × 1350 px (4:5) social artwork.
- Purple / black / white palette drawn from the supplied opener and repository wordmark.
- Lower-left caption block with a short headline, supporting copy and CTA.
- Repository service backgrounds are preserved as supplied; the design adds a dark readable gradient and purple frame.
- Copy avoids guarantees of funding, approval, introductions, insurance cover, specialist outcomes, buyers or sales.

## Files

- `campaign.html` — editable single-source layout and copy.
- `assets/` — copied repository backgrounds and wordmark.
- `renders/` — one PNG per service.
- `reference-opener.png` — supplied opener retained unchanged as the palette/style reference.
