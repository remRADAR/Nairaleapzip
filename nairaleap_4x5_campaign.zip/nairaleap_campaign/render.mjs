import { chromium } from 'playwright';
import fs from 'fs';
const browser = await chromium.launch({headless:true});
const page = await browser.newPage({viewport:{width:1080,height:1350}, deviceScaleFactor:1});
await page.goto('file:///home/ubuntu/nairaleap_campaign/campaign.html');
await page.waitForTimeout(1200);
for (const el of await page.locator('.stage').all()) {
  const id = await el.getAttribute('data-id');
  await el.screenshot({path:`/home/ubuntu/nairaleap_campaign/renders/${id}.png`});
}
await browser.close();
